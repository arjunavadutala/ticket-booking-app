/**
 * BookingSummary – confirmation screen shown after a successful booking.
 * Props:
 *   booking   – { name, tickets, total, ticketId }
 *   eventName – string
 *   onReset   – callback to go back to the booking form
 */
export default function BookingSummary({ booking, eventName, onReset }) {
  const { name, tickets, total, ticketId } = booking;

  return (
    <div className="card summary-card">
      {/* Success icon */}
      <div className="success-icon" aria-hidden="true">✓</div>

      <h2 className="summary-title">Booking Confirmed!</h2>
      <p className="summary-subtitle">
        You're all set for <strong>{eventName}</strong>. Save your Ticket ID
        for entry.
      </p>

      {/* Detail rows */}
      <div className="summary-details">
        <SummaryRow label="Attendee Name" value={name} />
        <SummaryRow label="Event" value={eventName} />
        <SummaryRow
          label="Tickets Booked"
          value={`${tickets} ticket${tickets > 1 ? "s" : ""}`}
        />
        <SummaryRow
          label="Total Amount"
          value={`₹${total.toLocaleString("en-IN")}`}
          highlight
        />
      </div>

      {/* Ticket ID badge */}
      <div className="ticket-id-block">
        <p className="ticket-id-label">Your Ticket ID</p>
        <p className="ticket-id-value">{ticketId}</p>
        <p className="ticket-id-note">
          Screenshot or note this ID — it's needed for entry and tracking.
        </p>
      </div>

      {/* Book another */}
      <button className="btn btn-primary" onClick={onReset}>
        ← Book Another Ticket
      </button>
    </div>
  );
}

/** Individual detail row */
function SummaryRow({ label, value, highlight }) {
  return (
    <div className={`summary-row${highlight ? " highlight" : ""}`}>
      <span className="summary-label">{label}</span>
      <span className="summary-value">{value}</span>
    </div>
  );
}
