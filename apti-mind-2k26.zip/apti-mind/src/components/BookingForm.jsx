import { useState } from "react";

// Email validation regex (RFC-5322 simplified)
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * BookingForm – collects user details and triggers onBook callback.
 * Props:
 *   config    – EVENT_CONFIG
 *   available – current available tickets
 *   onBook    – callback({ name, email, department, tickets })
 */
export default function BookingForm({ config, available, onBook }) {
  // ── Form state ─────────────────────────────────────────────────────────────
  const [form, setForm] = useState({
    name: "",
    email: "",
    department: "",
    tickets: "",
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const soldOut = available === 0;

  // ── Field change handler ───────────────────────────────────────────────────
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    // Clear error on edit
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  // ── Validation ─────────────────────────────────────────────────────────────
  const validate = () => {
    const newErrors = {};

    if (!form.name.trim()) {
      newErrors.name = "Full name is required.";
    }

    if (!form.email.trim()) {
      newErrors.email = "Email address is required.";
    } else if (!EMAIL_REGEX.test(form.email.trim())) {
      newErrors.email = "Enter a valid email address.";
    }

    if (!form.department.trim()) {
      newErrors.department = "Department is required.";
    }

    const ticketNum = parseInt(form.tickets, 10);
    if (!form.tickets || isNaN(ticketNum)) {
      newErrors.tickets = "Number of tickets is required.";
    } else if (ticketNum <= 0) {
      newErrors.tickets = "Must book at least 1 ticket.";
    } else if (ticketNum > available) {
      newErrors.tickets = `Only ${available} ticket(s) available.`;
    } else if (ticketNum > 10) {
      newErrors.tickets = "Maximum 10 tickets per booking.";
    }

    return newErrors;
  };

  // ── Submit handler ─────────────────────────────────────────────────────────
  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setSubmitting(true);
    // Simulate brief async delay for UX feel
    setTimeout(() => {
      onBook({
        name: form.name.trim(),
        email: form.email.trim(),
        department: form.department.trim(),
        tickets: parseInt(form.tickets, 10),
      });
      setSubmitting(false);
    }, 600);
  };

  // ── Reset ──────────────────────────────────────────────────────────────────
  const handleReset = () => {
    setForm({ name: "", email: "", department: "", tickets: "" });
    setErrors({});
  };

  // ── Derived ───────────────────────────────────────────────────────────────
  const ticketNum = parseInt(form.tickets, 10);
  const liveTotal =
    !isNaN(ticketNum) && ticketNum > 0
      ? ticketNum * config.ticketPrice
      : null;

  if (soldOut) {
    return (
      <div className="card sold-out-card">
        <div className="sold-out-icon">🎫</div>
        <h2 className="sold-out-title">Tickets Sold Out</h2>
        <p className="sold-out-sub">
          All {config.totalTickets} tickets for {config.eventName} have been
          claimed. Stay tuned for future events!
        </p>
      </div>
    );
  }

  return (
    <form className="card booking-form" onSubmit={handleSubmit} noValidate>
      <h2 className="form-title">Reserve Your Spot</h2>

      {/* Full Name */}
      <div className="field-group">
        <label className="field-label" htmlFor="name">
          Full Name <span className="required">*</span>
        </label>
        <input
          id="name"
          name="name"
          type="text"
          className={`field-input${errors.name ? " error" : ""}`}
          placeholder="e.g. Arjun Krishnamurthy"
          value={form.name}
          onChange={handleChange}
          disabled={submitting}
        />
        {errors.name && <p className="field-error">{errors.name}</p>}
      </div>

      {/* Email */}
      <div className="field-group">
        <label className="field-label" htmlFor="email">
          Email Address <span className="required">*</span>
        </label>
        <input
          id="email"
          name="email"
          type="email"
          className={`field-input${errors.email ? " error" : ""}`}
          placeholder="arjun@example.com"
          value={form.email}
          onChange={handleChange}
          disabled={submitting}
        />
        {errors.email && <p className="field-error">{errors.email}</p>}
      </div>

      {/* Department */}
      <div className="field-group">
        <label className="field-label" htmlFor="department">
          Department <span className="required">*</span>
        </label>
        <input
          id="department"
          name="department"
          type="text"
          className={`field-input${errors.department ? " error" : ""}`}
          placeholder="e.g. Computer Science & Engineering"
          value={form.department}
          onChange={handleChange}
          disabled={submitting}
        />
        {errors.department && (
          <p className="field-error">{errors.department}</p>
        )}
      </div>

      {/* Number of Tickets */}
      <div className="field-group">
        <label className="field-label" htmlFor="tickets">
          Number of Tickets <span className="required">*</span>
        </label>
        <input
          id="tickets"
          name="tickets"
          type="number"
          min="1"
          max={Math.min(available, 10)}
          className={`field-input${errors.tickets ? " error" : ""}`}
          placeholder="1 – 10"
          value={form.tickets}
          onChange={handleChange}
          disabled={submitting}
        />
        {errors.tickets && <p className="field-error">{errors.tickets}</p>}
      </div>

      {/* Live total preview */}
      {liveTotal !== null && (
        <div className="total-preview">
          <span>Estimated Total</span>
          <span className="total-amount">₹{liveTotal.toLocaleString("en-IN")}</span>
        </div>
      )}

      {/* Actions */}
      <div className="form-actions">
        <button
          type="button"
          className="btn btn-ghost"
          onClick={handleReset}
          disabled={submitting}
        >
          Reset
        </button>
        <button
          type="submit"
          className="btn btn-primary"
          disabled={submitting}
        >
          {submitting ? "Processing…" : "Confirm Booking →"}
        </button>
      </div>
    </form>
  );
}
