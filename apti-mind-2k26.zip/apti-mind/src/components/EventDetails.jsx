/**
 * EventDetails – displays event metadata and live ticket availability.
 * Props:
 *   config  – EVENT_CONFIG object from App
 *   available – current available ticket count
 */
export default function EventDetails({ config, available }) {
  const soldOut = available === 0;
  const pctLeft = Math.round((available / config.totalTickets) * 100);

  return (
    <section className="event-details card">
      {/* Department */}
      <p className="dept-label">{config.department}</p>

      {/* Info grid */}
      <div className="info-grid">
        <InfoItem icon="📅" label="Date" value={config.date} />
        <InfoItem icon="🕘" label="Time" value={config.time} />
        <InfoItem icon="📍" label="Venue" value={config.venue} />
        <InfoItem
          icon="💰"
          label="Ticket Price"
          value={`₹${config.ticketPrice} per ticket`}
          highlight
        />
      </div>

      {/* Availability bar */}
      <div className="availability-block">
        <div className="avail-header">
          <span className="avail-label">Availability</span>
          {soldOut ? (
            <span className="sold-out-badge">🔴 SOLD OUT</span>
          ) : (
            <span className="avail-count">
              <strong>{available}</strong> / {config.totalTickets} remaining
            </span>
          )}
        </div>
        <div className="progress-track">
          <div
            className={`progress-fill${soldOut ? " sold" : pctLeft < 20 ? " low" : ""}`}
            style={{ width: `${pctLeft}%` }}
          />
        </div>
      </div>
    </section>
  );
}

/** Small helper for each info row */
function InfoItem({ icon, label, value, highlight }) {
  return (
    <div className={`info-item${highlight ? " highlight" : ""}`}>
      <span className="info-icon">{icon}</span>
      <div>
        <p className="info-label">{label}</p>
        <p className="info-value">{value}</p>
      </div>
    </div>
  );
}
