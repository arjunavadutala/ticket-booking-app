import { useState } from "react";

/**
 * TicketTracking – privacy-focused ticket lookup by ID.
 * Does NOT expose the booking list; only returns data for a known Ticket ID.
 * Props:
 *   bookings – { [ticketId]: { name, tickets, total, ... } }
 */
export default function TicketTracking({ bookings }) {
  const [inputId, setInputId] = useState("");
  const [result, setResult] = useState(null); // null | "not-found" | booking obj
  const [searched, setSearched] = useState(false);

  // ── Search handler ─────────────────────────────────────────────────────────
  const handleSearch = (e) => {
    e.preventDefault();
    const trimmed = inputId.trim().toUpperCase();

    if (!trimmed) return;

    const booking = bookings[trimmed];
    setResult(booking || "not-found");
    setSearched(true);
  };

  // ── Clear ──────────────────────────────────────────────────────────────────
  const handleClear = () => {
    setInputId("");
    setResult(null);
    setSearched(false);
  };

  return (
    <div className="card tracking-card">
      <h2 className="form-title">Track Your Ticket</h2>
      <p className="tracking-sub">
        Enter your Ticket ID (format: TXP-2026-XXXXX) to view your booking
        details.
      </p>

      {/* Search form */}
      <form className="track-form" onSubmit={handleSearch}>
        <input
          type="text"
          className="field-input track-input"
          placeholder="TXP-2026-XXXXX"
          value={inputId}
          onChange={(e) => {
            setInputId(e.target.value);
            if (searched) { setResult(null); setSearched(false); }
          }}
          maxLength={14}
          spellCheck={false}
        />
        <button type="submit" className="btn btn-primary" disabled={!inputId.trim()}>
          Search
        </button>
      </form>

      {/* Results */}
      {searched && result === "not-found" && (
        <div className="track-result error-result">
          <span className="result-icon">❌</span>
          <p className="result-message">
            No booking found for <strong>{inputId.trim().toUpperCase()}</strong>.
            Please double-check your Ticket ID.
          </p>
        </div>
      )}

      {searched && result && result !== "not-found" && (
        <div className="track-result success-result">
          <span className="result-icon">✅</span>
          <h3 className="result-heading">Booking Found</h3>
          <div className="summary-details">
            <TrackRow label="Attendee Name" value={result.name} />
            <TrackRow
              label="Tickets Booked"
              value={`${result.tickets} ticket${result.tickets > 1 ? "s" : ""}`}
            />
            <TrackRow
              label="Total Amount"
              value={`₹${result.total.toLocaleString("en-IN")}`}
              highlight
            />
            <TrackRow label="Ticket ID" value={result.ticketId} mono />
          </div>
        </div>
      )}

      {/* Clear button */}
      {searched && (
        <button className="btn btn-ghost clear-btn" onClick={handleClear}>
          Clear Search
        </button>
      )}

      {/* Privacy note */}
      <p className="privacy-note">
        🔒 Booking details are private and only accessible via your unique
        Ticket ID.
      </p>
    </div>
  );
}

/** Row helper */
function TrackRow({ label, value, highlight, mono }) {
  return (
    <div className={`summary-row${highlight ? " highlight" : ""}`}>
      <span className="summary-label">{label}</span>
      <span className={`summary-value${mono ? " mono" : ""}`}>{value}</span>
    </div>
  );
}
