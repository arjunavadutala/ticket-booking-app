import { useState } from "react";
import EventDetails from "./components/EventDetails";
import BookingForm from "./components/BookingForm";
import BookingSummary from "./components/BookingSummary";
import TicketTracking from "./components/TicketTracking";
import "./App.css";

// ── Initial event configuration ──────────────────────────────────────────────
const EVENT_CONFIG = {
  institution: "Vel Tech University",
  department: "Department of Computer Science & Engineering",
  eventName: "APTI MIND 2K26",
  tagline: "National Level Technical Symposium",
  date: "Saturday, 15 March 2026",
  time: "9:00 AM – 5:00 PM IST",
  venue: "Main Auditorium, Vel Tech University, Avadi, Chennai – 600 062",
  ticketPrice: 299,
  totalTickets: 250,
};

// ── Unique Ticket ID generator ────────────────────────────────────────────────
const generateTicketId = () => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const suffix = Array.from({ length: 5 }, () =>
    chars.charAt(Math.floor(Math.random() * chars.length))
  ).join("");
  return `TXP-2026-${suffix}`;
};

export default function App() {
  // ── State ──────────────────────────────────────────────────────────────────
  const [availableTickets, setAvailableTickets] = useState(
    EVENT_CONFIG.totalTickets
  );
  // bookings: object keyed by ticketId
  const [bookings, setBookings] = useState({});
  // The most recent booking (drives confirmation screen)
  const [lastBooking, setLastBooking] = useState(null);
  // Active tab: "book" | "track"
  const [activeTab, setActiveTab] = useState("book");

  // ── Booking handler ────────────────────────────────────────────────────────
  const handleBooking = ({ name, email, department, tickets }) => {
    const ticketId = generateTicketId();
    const total = tickets * EVENT_CONFIG.ticketPrice;
    const booking = { name, email, department, tickets, total, ticketId };

    setBookings((prev) => ({ ...prev, [ticketId]: booking }));
    setAvailableTickets((prev) => prev - tickets);
    setLastBooking(booking);
  };

  // ── Reset after viewing confirmation ──────────────────────────────────────
  const handleReset = () => setLastBooking(null);

  return (
    <div className="app">
      {/* Decorative grid overlay */}
      <div className="grid-overlay" aria-hidden="true" />

      {/* ── Header ── */}
      <header className="header">
        <div className="header-inner">
          <div className="institution-badge">
            <span className="badge-dot" />
            {EVENT_CONFIG.institution}
          </div>
          <h1 className="event-title">
            APTI <span className="accent">MIND</span> 2K26
          </h1>
          <p className="event-tagline">{EVENT_CONFIG.tagline}</p>
        </div>
        <div className="header-glow" aria-hidden="true" />
      </header>

      {/* ── Main content ── */}
      <main className="main">
        <EventDetails config={EVENT_CONFIG} available={availableTickets} />

        {/* Tab navigation */}
        <nav className="tab-nav" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === "book"}
            className={`tab-btn${activeTab === "book" ? " active" : ""}`}
            onClick={() => { setActiveTab("book"); }}
          >
            🎟&nbsp; Book Tickets
          </button>
          <button
            role="tab"
            aria-selected={activeTab === "track"}
            className={`tab-btn${activeTab === "track" ? " active" : ""}`}
            onClick={() => setActiveTab("track")}
          >
            🔍&nbsp; Track Ticket
          </button>
        </nav>

        {/* Tab panels */}
        <div className="panel">
          {activeTab === "book" ? (
            lastBooking ? (
              <BookingSummary
                booking={lastBooking}
                eventName={EVENT_CONFIG.eventName}
                onReset={handleReset}
              />
            ) : (
              <BookingForm
                config={EVENT_CONFIG}
                available={availableTickets}
                onBook={handleBooking}
              />
            )
          ) : (
            <TicketTracking bookings={bookings} />
          )}
        </div>
      </main>

      {/* ── Footer ── */}
      <footer className="footer">
        © 2026 {EVENT_CONFIG.institution} &nbsp;·&nbsp; All rights reserved
      </footer>
    </div>
  );
}
